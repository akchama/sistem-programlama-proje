## SİSTEM PROGRAMLAMA PROJE ÖDEVİ

# GRUP ÜYELERİ:
Abdullah Akçam - g140910076
Büşra Kaynak - b171210030
Cengizhan Koçal - g201210376
Merve Yılmaz -  b171210054

# Projeyi indirip derleme:
1. git clone https://github.com/haxcat5/sistem-programlama-proje.git
2. cd sistem-programlama-proje
3. make

# Projenin çalıştırılması:
1. Encoding: ./kripto -e [giris_dosyasi.txt] [cikis_dosyasi]
2. Decoding: ./kripto -d [giris_dosyasi] [cikis_dosyasi.txt]